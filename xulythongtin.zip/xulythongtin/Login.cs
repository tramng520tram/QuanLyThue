﻿using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xulythongtin
{
    public partial class Login : Form
    {
        string connectstring = "Data Source=LAPTOP-04V4MET6\\CT28101_TDU;Initial Catalog=quanlythongtin;Integrated Security=True;Encrypt=False";
        public Login()
        {
            InitializeComponent();
            txtPassword.PasswordChar = '●';
        }

        private void bthLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            // Mã hóa mật khẩu người dùng nhập vào thành MD5
            string hashedPassword = ComputeMd5Hash(password);

            // Kiểm tra tính đúng đắn của tên đăng nhập và mật khẩu
            if (CheckLogin(username, hashedPassword))
            {
                //MessageBox.Show("Đăng nhập thành công!");
                // Chuyển hướng tới form chính hoặc thực hiện các hành động tiếp theo
                this.Hide();
                Form1 mainForm = new Form1();
                mainForm.Show();
            }
            else
            {
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng.");
            }
        }
        private string ComputeMd5Hash(string rawData)
        {
            // Tạo MD5
            using (MD5 md5Hash = MD5.Create())
            {
                // Chuyển đổi chuỗi thành byte array và tính toán hash
                byte[] bytes = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                // Chuyển đổi byte array thành chuỗi hex
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        private bool CheckLogin(string username, string password)
        {
            // Thực hiện truy vấn SQL để kiểm tra tên đăng nhập và mật khẩu
            using (SqlConnection con = new SqlConnection(connectstring))
            {
                con.Open();

                string query = "SELECT COUNT(*) FROM taikhoan WHERE username=@username AND password=@password";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    return count > 0;
                }
            }
        }
    }
}
