﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace xulythongtin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        quanlythongtinEntities data = new quanlythongtinEntities();
        public static int Id = -1;

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
            dgThongtin.RowHeaderMouseClick += dgThongtin_RowHeaderMouseClick;

            // Tạo đối tượng danh mục mặc định
            danhmuc dv = new danhmuc
            {
                id = 0,
                TenVietTat = "Tất cả",
                TenDayDu = "Tất cả"
            };

            // Lấy danh sách danh mục từ database và chèn danh mục mặc định vào vị trí đầu tiên
            List<danhmuc> danhMucList = data.danhmucs.ToList();
            danhMucList.Insert(0, dv);

            // Thiết lập ComboBox Danh mục
            cbDanhmuc.DisplayMember = "TenVietTat";
            cbDanhmuc.ValueMember = "id";
            cbDanhmuc.DataSource = danhMucList;

            // Xử lý sự kiện SelectedIndexChanged của ComboBox Danh mục
            cbDanhmuc.SelectedIndexChanged += cbDanhmuc_SelectedIndexChanged;
        }


        public void LoadData()
        {
            dgThongtin.DataSource = data.xulytts.ToList();


        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                var xl = new xulytt
                {
                    TomTat = string.IsNullOrEmpty(txtTomTat.Text) ? null : txtTomTat.Text,
                    XuLy = string.IsNullOrEmpty(txtXuLy.Text) ? null : txtXuLy.Text,
                    NoiDung = string.IsNullOrEmpty(txtNoiDung.Text) ? null : txtNoiDung.Text
                };

                data.xulytts.Add(xl);
                data.SaveChanges();
                MessageBox.Show("Thêm thông tin thành công!");
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi thêm thông tin: {ex.Message}");
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (Id > 0)
            {
                try
                {
                    var xulytt = data.xulytts.SingleOrDefault(m => m.id == Id);
                    if (xulytt != null)
                    {
                        xulytt.TomTat = txtTomTat.Text;
                        xulytt.XuLy = txtXuLy.Text;
                        xulytt.NoiDung = txtNoiDung.Text;

                        data.SaveChanges();
                        MessageBox.Show("Cập nhật thành công");
                        LoadData();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi khi cập nhật thông tin: {ex.Message}");
                }
            }
        }

        private void dgThongtin_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgThongtin.Rows[e.RowIndex] != null)
            {
                Id = dgThongtin.Rows[e.RowIndex].Cells[0].Value != null ? Convert.ToInt32(dgThongtin.Rows[e.RowIndex].Cells[0].Value) : -1;

                txtTomTat.Text = dgThongtin.Rows[e.RowIndex].Cells[1].Value?.ToString() ?? "";
                txtXuLy.Text = dgThongtin.Rows[e.RowIndex].Cells[2].Value?.ToString() ?? "";
                txtNoiDung.Text = dgThongtin.Rows[e.RowIndex].Cells[3].Value?.ToString() ?? "";
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgThongtin.SelectedRows.Count > 0)
            {
                try
                {
                    foreach (DataGridViewRow row in dgThongtin.SelectedRows)
                    {
                        if (row.Cells[0].Value != null && int.TryParse(row.Cells[0].Value.ToString(), out int id))
                        {
                            var xltt = data.xulytts.SingleOrDefault(x => x.id == id);
                            if (xltt != null)
                            {
                                data.xulytts.Remove(xltt);
                            }
                            else
                            {
                                MessageBox.Show($"Không tìm thấy thông tin với ID: {id}");
                            }
                        }
                        else
                        {
                            MessageBox.Show($"Giá trị ID không hợp lệ: {row.Cells[0].Value}");
                        }
                    }
                    data.SaveChanges();
                    MessageBox.Show("Xóa dữ liệu thành công");
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi khi xóa dữ liệu: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn ít nhất một hàng để xóa.");
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            try
            {
                // Lấy giá trị từ các ô tìm kiếm
                string tomTat = txtTomTat.Text.Trim();
                string noiDung = txtNoiDung.Text.Trim();
                string xuLy = txtXuLy.Text.Trim();

                // Tạo truy vấn ban đầu từ DbContext
                var query = data.xulytts.AsQueryable();

                // Áp dụng các điều kiện tìm kiếm dựa trên giá trị đầu vào
                if (!string.IsNullOrEmpty(tomTat))
                {
                    query = query.Where(x => x.TomTat.Contains(tomTat));
                }
                if (!string.IsNullOrEmpty(noiDung))
                {
                    query = query.Where(x => x.NoiDung.Contains(noiDung));
                }
                if (!string.IsNullOrEmpty(xuLy))
                {
                    query = query.Where(x => x.XuLy.Contains(xuLy));
                }

                // Cập nhật DataGridView với kết quả tìm kiếm
                dgThongtin.DataSource = query.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi tìm kiếm: {ex.Message}");
            }
        }


        // Phần tìm kiếm nó bị riêng biệt, nó là nhập trong 3 để tìm kiếm.
        // bây giờ nó muốn có các câu có quan hệ với nhau, có thể nhập ô này mà ô kia rỗng không tìm được nội dung nữa

        private void btnExcel_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xls;*.xlsx;*.xlsm",
                Title = "Chọn tệp Excel"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string excelFilePath = openFileDialog.FileName;

                    DataTable dataTable = ReadExcel(excelFilePath);

                    foreach (DataRow row in dataTable.Rows)
                    {
                        var xl = new xulytt
                        {
                            TomTat = row["TomTat"].ToString(),
                            XuLy = row["XuLy"].ToString(),
                            NoiDung = row["NoiDung"].ToString()
                        };
                        data.xulytts.Add(xl);
                    }
                    data.SaveChanges();
                    LoadData();
                    MessageBox.Show("Nhập dữ liệu từ Excel thành công!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi khi nhập dữ liệu từ Excel: {ex.Message}");
                }
            }
        }

        private DataTable ReadExcel(string filePath)
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (var workBook = new XLWorkbook(filePath))
                {
                    var workSheet = workBook.Worksheet(1);
                    var range = workSheet.RangeUsed();
                    bool firstRow = true;

                    foreach (var row in range.Rows())
                    {
                        if (firstRow)
                        {
                            foreach (var cell in row.Cells())
                            {
                                dataTable.Columns.Add(cell.Value.ToString());
                            }
                            firstRow = false;
                        }
                        else
                        {
                            var dataRow = dataTable.NewRow();
                            int i = 0;
                            foreach (var cell in row.Cells())
                            {
                                dataRow[i++] = cell.Value.ToString();
                            }
                            dataTable.Rows.Add(dataRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi đọc tệp Excel: {ex.Message}");
            }
            return dataTable;
        }

        //private void cbDanhmuc_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    //try
        //    //{
        //    //    int selectedId = Convert.ToInt32(cbDanhmuc.SelectedValue);

        //    //    var query = data.nangcaps.AsQueryable();

        //    //    if (selectedId != 0) // 0 là "Tất cả"
        //    //    {
        //    //        query = query.Where(nc => nc.id_danhmuc == selectedId);
        //    //    }

        //    //    dgThongtin.DataSource = query.ToList();
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    MessageBox.Show($"Đã xảy ra lỗi khi đọc dữ liệu: {ex.Message}");
        //    //}
        //}


        private void btnUpload_Click(object sender, EventArgs e)
        {
            LoadData();
            
        }

        private void cbDanhmuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // Lấy id của danh mục được chọn
                int selectedId = Convert.ToInt32(cbDanhmuc.SelectedValue);

                // Truy vấn dữ liệu dựa trên danh mục được chọn
                var query = data.danhmucs.AsQueryable();

                if (selectedId != 0) // 0 là "Tất cả"
                {
                    query = query.Where(d => d.id == selectedId);
                }

                // Hiển thị dữ liệu trong DataGridView
                dgThongtin.DataSource = query.Select(d => new { d.id, d.TenVietTat, d.TenDayDu }).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi lọc dữ liệu: {ex.Message}");
            }
        }

    }
}
